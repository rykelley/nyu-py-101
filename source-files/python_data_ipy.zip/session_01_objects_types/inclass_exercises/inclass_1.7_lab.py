# 1.7:  Square a number.

import runreport

gg = 5


# Expected Output:

# 25

