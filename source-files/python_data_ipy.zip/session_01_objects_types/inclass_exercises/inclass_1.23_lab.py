# 1.23:  Take input and print the user's value 3 times as a
# single string.

import runreport

val = input('please type anything: ')


# Expected Output:

# spamspamspam   (assumes the user typed spam)

