# 1.28:  Take float input and round it.

import runreport

ui = input('please enter a floating-point number: ')


# Expected Output:

# 3.93             (assumes user typed 3.926)

