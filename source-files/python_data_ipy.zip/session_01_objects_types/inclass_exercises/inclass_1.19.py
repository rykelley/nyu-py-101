# 1.19:  Replicating code examples (2/2).

# Review pythonreference.com for the function round().
# Perform operations listed below:

myfloat = 3.927


# round myfloat to 2 decimal places (should be 3.93).



# round myfloat to 0 places (i.e., to produce an integer - should be 4)



