# 1.12:  Use the variable 'x' below to make a 40-character
# dotted line.

import runreport

x = '-'


# Expected Output:

# ----------------------------------------

