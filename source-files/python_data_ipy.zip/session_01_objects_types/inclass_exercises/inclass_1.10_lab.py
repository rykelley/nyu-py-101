# 1.10:  Calculate a tip.

# With a bill of $100, 5 people in your party and a 20% tip,
# how much does each person owe?

import runreport

bill = 100
people = 5
tip_pct = 20


# Expected Output:

# 24.0

