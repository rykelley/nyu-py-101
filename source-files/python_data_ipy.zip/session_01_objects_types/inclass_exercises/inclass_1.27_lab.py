# 1.27:  Take a number and repeat it 3 times.

import runreport

yxy = 500


# Expected Output:

# 500500500

