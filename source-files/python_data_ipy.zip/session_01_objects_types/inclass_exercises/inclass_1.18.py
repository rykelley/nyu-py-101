# 1.18:  Replicating code examples (1/2).

# Review pythonreference.com for the function len().  Use
# len() to check the length of the variable sentence (length
# should be 3).  Next, use len() to check the length of the
# literal string value 'sentence' (length should be 8).

sentence = 'hi!'


# Please note that variable sentence (no quotes) is entirely
# different from string 'sentence' (with quotes).  A word
# without quotes is a variable (a value assigned to a name).
# A word with quotes around it is a string literal (a literal
# string value).

