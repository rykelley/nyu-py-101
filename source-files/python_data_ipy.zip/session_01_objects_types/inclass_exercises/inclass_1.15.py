# 1.15:  Integerize a float value with int().

# Use the int() function to round the number 43.985 down to
# 43.

x = 43.985



# Expected Output:

# 43

