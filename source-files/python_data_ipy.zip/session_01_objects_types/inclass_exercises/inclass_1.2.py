# 1.2:  Math operators.

# Multiply 'a' by 'b' and divide by 'c' (result should be
# 25.0).

a = 5
b = 10
c = 2


