# 1.22:  Take input for name and print 'hello, [name]!'.

import runreport

name = input('please enter your name: ')


# Expected Output:

# Hello, David!  (assumes the user typed David)

