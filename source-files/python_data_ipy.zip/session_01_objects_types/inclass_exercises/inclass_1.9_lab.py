# 1.9:  Add two numbers together and then divide by 2.

import runreport

aa = 3
myb = 5



# Expected Output:

# 4.0

# Consider that the division operator gets evaluated before
# the plus operator.  If you are calculating both in the same
# statement, use parentheses to cause Python to evaluate the
# plus first.

