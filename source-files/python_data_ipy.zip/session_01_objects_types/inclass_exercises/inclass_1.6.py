# 1.6:  String repetition operator.

# Use '*' to repeat the string in greet 3 times to return a
# new str value yoyoyo.

greet = 'yo'


