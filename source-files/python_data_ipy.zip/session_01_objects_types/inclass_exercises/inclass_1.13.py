# 1.13:  Get the length of strings with len().

# Print the length of each of the below strings.  Both strings
# should be length of 11.

x = 'hello there'

y = 'hi       ok'




# Expected Output:

# 11
# 11

