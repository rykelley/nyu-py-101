# 1.26:  Take 2 numbers and concatenate them.

import runreport

xx = 65
yy = 43


# Expected Output:

# 6543

