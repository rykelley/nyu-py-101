# 1.17:  int(), float() and str() functions.

# Convert the below string to an integer, then double the
# value (to 106).  Convert this value to a float (106.0) and
# convert that value to a string.  Retrieve and print the
# length of this string (should be 5).

zzy = '53'


