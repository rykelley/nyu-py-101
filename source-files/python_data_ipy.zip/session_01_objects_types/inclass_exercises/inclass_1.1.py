# 1.1:  Numeric and string assignment, and type() function.

# Assign an integer to new variable 'vari', a float to 'varf'
# and a string to 'varstr'.  Print, and use the type()
# function to print the value and type of one or more of them.



