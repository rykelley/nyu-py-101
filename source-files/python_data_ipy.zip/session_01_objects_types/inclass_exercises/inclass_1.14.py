# 1.14:  Round numbers with round().

# Round the number to two places (43.99), and to an int (44).

x = 43.985



# Expected Output:

# 43.99
# 44

