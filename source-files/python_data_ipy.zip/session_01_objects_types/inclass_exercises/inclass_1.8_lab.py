# 1.8:  Multiply 2 numbers, then square the result.

import runreport

xx = 5
yy = 3


# Expected Output:

# 225

# Note that the exponientation operator has greater precedence
# than the multiplication operator, so it is evaluated first.
# You must use parentheses to enforce a different precendence.

