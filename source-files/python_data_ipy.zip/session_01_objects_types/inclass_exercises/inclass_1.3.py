# 1.3:  Exponentiation operator.

# Use '**' to raise a to the power of b (result should be
# 125).

a = 5
b = 3


