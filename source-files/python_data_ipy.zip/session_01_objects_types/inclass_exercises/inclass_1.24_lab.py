# 1.24:  Take input for a number and double it.

import runreport

x = input('Please enter a number: ')


# Expected Output:

# 20             (assumes the user typed 10)

