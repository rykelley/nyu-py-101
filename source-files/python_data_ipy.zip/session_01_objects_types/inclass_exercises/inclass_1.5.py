# 1.5:  Concatenation operator.

# Use '+' to concatenate xvar, yvar and zvar together.

xvar = 'supercali'
yvar = 'fragilistic'
zvar = 'expialidocious'


