# 1.11:  Concatenate strings together into a sentence.

# See if you can make the output look as expected.

import runreport

adjective = 'happy'
event = 'birthday'

# Expected Output:

# happy birthday

