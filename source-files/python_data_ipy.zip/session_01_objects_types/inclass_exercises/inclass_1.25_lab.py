# 1.25:  Get the length of 1000000.

import runreport

n = 1000000


# Expected Output:

# 7

