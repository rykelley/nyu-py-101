# 1.21:  Divide 5 by 3 and round to 2 places.

import runreport

xx = 5
goofy = 3


# Expected Output:

# 1.67

