# 1.20:  Get the character length of the preamble to the
# constitution.

import runreport

preamble = """We the People of the United States, in Order to form a more
perfect Union, establish Justice, insure domestic Tranquility, provide for
the common defense, promote the general Welfare, and secure the Blessings
of Liberty to ourselves and our Posterity, do ordain and establish
this Constitution for the United States of America."""


# Expected Output:

# 327

