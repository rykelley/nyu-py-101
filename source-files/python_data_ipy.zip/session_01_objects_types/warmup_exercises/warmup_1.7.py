# 1.7:  Assign the float value 35.30 to a variable, then round
# the value to 35.



# Expected Output:

# 35

