# 1.8:  Assign the float value 35.359958 to a variable, then
# round the value to two decimal places.



# Expected Output:

# 35.36

