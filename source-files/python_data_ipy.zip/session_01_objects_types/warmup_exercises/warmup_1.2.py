# 1.2:  Assign two new integer objects to two variable names.
# Multiply the two variables and assign the resulting object
# to a new variable name.  Indicate (by printing) the value
# and type of this resulting variable's object.



