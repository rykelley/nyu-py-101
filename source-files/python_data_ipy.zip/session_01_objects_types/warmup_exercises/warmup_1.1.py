# 1.1:  Assign two new integer objects and one float object to
# three variable names.  Sum up the three variables and assign
# the resulting object to a new variable name.  Indicate (by
# printing) the value and type of this resulting object.



