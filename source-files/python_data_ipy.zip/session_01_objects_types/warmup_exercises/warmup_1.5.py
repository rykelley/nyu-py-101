# 1.5:  Take user input for a 'place' and then greet the place
# enthusiastically.



# Sample program runs:

# Please enter a place name:  Hawaii
# Hello, Hawaii!

# Please enter a place name:  Kathmandu
# Hello, Kathmandu!

