# 1.6:  Take user input for an integer and apply that many
# exclamation points to the phrase, "Hello, world!"  (Hint:
# use the "string repetition" operator)



# Sample program runs:

# Please enter an integer:  2
# Hello, World!!

# Please enter an integer:  11
# Hello, World!!!!!!!!!!!

