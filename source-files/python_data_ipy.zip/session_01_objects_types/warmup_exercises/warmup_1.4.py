# 1.4:  Take user input for an integer and print that value
# doubled.



# Sample Output:

# Please enter an integer:  5
# 5 doubled is 10.

