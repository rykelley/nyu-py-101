# 1.9:  Starting with the following code (make sure it is
# included exactly as written), divide the first number by the
# second number.

var = "5"
var2 = "4"

# Expected Output:

# 1.25

