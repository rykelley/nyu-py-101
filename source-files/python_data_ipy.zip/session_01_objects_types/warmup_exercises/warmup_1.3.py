# 1.3:  Starting with the sample code, sum up the values to
# produce the integer value 15.  (Hint:  apply a conversion
# function to each string so it can be used as a number.)

var = '5'
var2 = '10'

# Expected Output:

# 15

