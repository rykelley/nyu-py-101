# 10.32:  Featured module:  subprocess.

import subprocess

subprocess.call(['python', 'hello.py'])

# out = subprocess.check_output(['python', 'hello.py')

