# 10.28:  pandas visualization.

# groupby bar chart


# weather temp line chart



