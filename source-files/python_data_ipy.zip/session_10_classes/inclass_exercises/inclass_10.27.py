# 10.27:  pandas data management.

df = pd.read_csv('../dated_file.csv')


# sum, average, etc. a column



# create a new column

# select rows thru a filter

# groupby aggregation




