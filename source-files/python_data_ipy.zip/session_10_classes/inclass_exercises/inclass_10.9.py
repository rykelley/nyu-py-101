# 10.9:  Set an instance attribute in __init__().

# Create a method __init__(self, num) that sets numin self as
# a .value attribute.  At bottom, print obj.value to see the
# value.

class Live:
    """ a class that just wants to live """
    # your __init__() code here


obj = Live(5)

# print obj.value here

# Expected Output:

# 5

