# 10.20:  Featured module:  time.

import time

secs = time.time()

# print(time.ctime(secs))

# print(time.localtime(secs))

# time.sleep(5)


