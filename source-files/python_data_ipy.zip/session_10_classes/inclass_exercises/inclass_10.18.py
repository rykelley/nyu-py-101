# 10.18:  Exploring documentation:  math.

# Do a google search for python documentation.  At the
# documentation page, choose Library Reference.  Note all the
# many modules listed on this page -- these are the modules
# that are included in the Python standard distribution -- the
# Python install provided by python.org.
# 
# Find the math module.  Below, see if you can import math and
# then make use of one of the functions in the module.

