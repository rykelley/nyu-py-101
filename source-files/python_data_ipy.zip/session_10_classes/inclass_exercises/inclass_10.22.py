# 10.22:  Featured module:  random.

import random

myfloat = random.random()

# num = random.randint(10)

# num = random.randint(3,5)

# x = ['a', 'b', 'c']

# choice = random.choice(x)

