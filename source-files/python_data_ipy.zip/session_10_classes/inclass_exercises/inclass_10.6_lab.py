# 10.6:  Create a class Math with method add() that takes two
# integer arguments and returns the values summed.

import runreport

# your code here



obj = Math()

mysum = obj.add(5, 10)        # 15
print(mysum)

mysum2 = obj.add(100, 150)    # 250
print(mysum2)

# Expected Output:

# 15
# 250

