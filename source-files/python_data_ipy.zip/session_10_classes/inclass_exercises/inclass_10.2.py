# 10.2:  Create an 'instance' method.

# Add to the class Hola below a new method, saludar(), that
# prints "bienvenidos a todos" (or whatever greeting you'd
# prefer) when it is called.

class Hola:
    """ una clase que is amigable """

    # your code here


yo = Hola()

yo.saludar()     # should print the greeting

# Expected Output:

# bienvenidos a todos

