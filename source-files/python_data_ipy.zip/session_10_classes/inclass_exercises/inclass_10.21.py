# 10.21:  Featured module:  datetime.

import datetime as dt

# mydate = dt.date(2019, 9, 3)

# mydate = dt.date.today()

# mydatetime = dt.datetime(2019, 9, 3, 12, 5, 30)

# mydatetime = dt.datetime.now()


#secs = time.time()
#time_elements = time.localtime(secs)
#print(time_elements)


# myinterval = dt.timedelta(days=3, seconds=120)

# newdate = mydate + myinterval

# print(newdate)

# print(newdate.strftime('%Y-%m-%d'))

# dt.datetime.strptime('2019-03-03', '%Y-%m-%d')

