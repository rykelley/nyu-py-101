# 2.22:  Create a while loop that breaks if user input equals
# a certain value.

# Inside a while True block, take user input.  If the user
# typed 'quit', break out of the loop.  Otherwise, allow the
# loop to loop back and ask again.

import runreport



