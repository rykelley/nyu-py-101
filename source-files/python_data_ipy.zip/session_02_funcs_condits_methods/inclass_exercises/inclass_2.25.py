# 2.25:  Use string methods that transform a string with the
# below operations.

# lowercase and print this string (use .lower())
xx = 'HELLO'


# uppercase and print this string (use .upper())
zz = 'what?'


# replace 'this' with 'that' in the sentence,
# then print the replaced string (use .replace())
sentence = "I can't say no to this."


# Expected Output:

# hello
# WHAT?
# I can't say no to that.

