# 2.29:  Check to see if a user's input string is all digits.

# Take user input and see if it is all digit characters.  If
# it is, print all digits, otherwise print not all digits.
# Make sure to test with all digits and with a string that is
# not all digits.

import runreport



