# 2.12:  Take user input, say if it is a substring of another
# string.

# If the user types a string of characters that can be found
# in test_string, print True otherwise print False.  Remember
# to test!

import runreport

test_string = 'Hello Pythonistas well met.'

ui = input('please enter a substring: ')


