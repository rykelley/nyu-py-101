# 2.20:  Review:  Modulus operator.

# What is a % b?  What is a % c?  Can you tell why this
# operator is returning these values?

a = 8
b = 3
c = 2

