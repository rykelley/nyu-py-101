# 2.4:  Test to see if one string can be found in another.

# Use if with in to see if the characters in varx can be found
# in vary; if so, print 'is a substring'.

varx = 'Python is awesome'
vary = 'awe'



# Expected Output:

# is a substring

