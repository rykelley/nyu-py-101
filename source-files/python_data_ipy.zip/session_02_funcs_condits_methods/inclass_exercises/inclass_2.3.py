# 2.3:  Use 'if' with 'elif' and 'else'.

# If variable 'myaa' is greater than variable 'mybb', print
# 'greater'; otherwise if 'myaa' is less than 'mybb', print
# 'lesser', otherwise, print 'equal'.  Again, change the
# values to prove that all 3 conditions are correctly handled.

myaa = 20
mybb = 10


