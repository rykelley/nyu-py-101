# 2.14:  Take user input for a number, say if it is less than
# one value and greater than another value.  If the user's
# number is less than 101 and greater than 0, print 'within
# range'; otherwise, print 'out of range'.

import runreport

ui = input('please enter an int value:  ')



