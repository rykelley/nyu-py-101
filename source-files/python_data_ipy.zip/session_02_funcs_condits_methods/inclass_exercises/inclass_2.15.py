# 2.15:  Increment a value 3 times.  In 3 statements, use
# incrementation (num = num + 1, or num += 1) to bring the
# value num to 3.

num = 0

num = num + 1
num = num + 1
num += 1           # same as above 2 statements

print(num)         # 3

