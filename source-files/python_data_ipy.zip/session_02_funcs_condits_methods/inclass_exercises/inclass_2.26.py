# 2.26:  Use string methods that evaluate a string.

# Perform the following operations:

# if string variable 'varstr' is all digits, print "all digits" (use .isdigit())
varstr = '555'



# if string variable 'varstr2' is not all digits, print "not all digits"
# (use 'not' in front of .isdigit()))
varstr2 = '555a'



# if the string 'filename' starts with a "." (period), print "hidden"
# (incidentally, this signifies a "hidden" file on your computer's filesystem)
# (use .startswith())
filename = '.hidden'



# if the string 'filename2' ends with '.txt' (a text file), print "text file"
# (use .endswith())
filename2 = 'myfile.txt'




# Expected Output:

# all digits
# hidden
# text file

