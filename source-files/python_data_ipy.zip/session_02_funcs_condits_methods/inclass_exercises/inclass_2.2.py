# 2.2:  Use 'if' with 'else'.

# If 'a' is greater than or equal to 'b', print 'greater than
# or equal to'.  Otherwise (without an additional test) print
# 'lesser than'.  Change the values to show both parts of the
# if/else are working correctly.

a = 5
b = 3


