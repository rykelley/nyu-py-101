# 2.18:  Use 'break' to break out of a loop if a condition is
# True.

# The below loop will loop indefinitely, asking the user for
# input (try it, then use the red square to the left of the
# Run window, or in Jupyter restart the kernel to get out of
# the loop).  Add a statement to test if equal to 'q', break
# out of the loop (otherwise, loop should take us back to
# input again).

while True:

    ui = input('please enter "q" to quit:  ')

    # your code here

    print('continuing...')


print('done')

