# 2.5:  Use 'or', 'and' and 'not' to perform the noted
# comparisons.

vara= 5
myb = -5

# single statement:  if variable 'vara' is greater than 0
# and also greater than 'myb', print 'ok1'


# single statement:  if variable 'vara' is greater than 0
# or 'myb' is greater than 0, print 'ok2'


# single statement:  if variable 'vara' is less than 0
# or 'myb' is not greater than 0, print 'ok3'



# Expected Output:

# ok1
# ok2
# ok3

