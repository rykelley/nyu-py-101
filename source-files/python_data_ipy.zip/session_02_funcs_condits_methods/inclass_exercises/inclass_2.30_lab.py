# 2.30:  Check to see if a user's input string starts with a
# substring.

# Take user input and if the input starts with a space
# character, print True otherwise print False.

import runreport



