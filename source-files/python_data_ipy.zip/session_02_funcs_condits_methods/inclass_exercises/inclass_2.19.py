# 2.19:  Use 'continue' to keep iterating.

# Run this code first.  Then if value of 'count' is < 3, use
# 'continue' to keep iterating without printing.    You should
# see only '3' and '4' printed.

maxval = 4
count = 0

while count < maxval:

    count = count + 1

    # your code here:  loop back if count < 3

    print(count)


print('done')

# Expected Output:

# 3
# 4
# done

