# 2.11:  Take user input for a number, then say whether the
# number is even or odd.  Remember to test for both!

import runreport

ui = input('please enter an int value: ')


