# 2.24:  Create a while loop that uses modulus to determine
# whether to continue.

# Create a while loop that increments the counter and stops
# looping if counter becomes greater than 10.
# 
# Now add an if statement that checks to see if counter is
# even.  If it is, it prints the counter.  You should see only
# even numbers printed.

import runreport

counter = 0


# Expected Output:

# 2
# 4
# 6
# 8
# 10

