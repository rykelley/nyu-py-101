# 2.21:  Create a while loop with a counter and terminal
# value.

# Inside a while block, increment the counter and print the
# counter value.  If the counter is greater than 3, the while
# loop should exit.  In other words, it should keep looping
# while it is less than or equal to 3 (do not use break here).

import runreport

counter = 0


# Expected Output:

# 1
# 2
# 3
# 4

