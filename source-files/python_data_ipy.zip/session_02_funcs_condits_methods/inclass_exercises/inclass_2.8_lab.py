# 2.8:  Compare user input to string.

# Take keyboard input from the user, then see if it is equal
# to 'quit'.  If it is, print quitting....  Make sure to test
# with 'quit' and with another input value.

import runreport



