# 2.31:  Insert a number into a string.

# Print Python was created in 1989. exactly as shown, without
# using str(), concatenation or a comma inside print() (or the
# literal value 1989 of course -- use anno).

import runreport

anno = 1989



# Expected Output:

# Python was created in 1989.

