# 2.13:  Take user input for a number, say if it is equal to
# one value or equal to another value.  If the user's number
# is equal to 5 or equal to 15, print 'true'; otherwise, print
# 'false'.

import runreport

ui = input('please enter an int value:  ')



