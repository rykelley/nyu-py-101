# 2.28:  Validate a user's input string, case-insensitively..

# Take user input, then check to see if it is equal to quit
# but in any string case (Quit, qUIt, QUIT, etc.)  Do not try
# to account for every combination -- instead, lowercase the
# user's string before testing.  Print 'quitting...'.  Make
# sure to test multiple combinations of case!

import runreport



