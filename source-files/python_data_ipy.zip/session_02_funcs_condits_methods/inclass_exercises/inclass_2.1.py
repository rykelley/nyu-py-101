# 2.1:  Use 'if' and 'if not' with comparison operators to
# perform the noted comparisons.

# if aa is greater than bb, print 'ok1' (use '>')
aa = 50
bb = 35


# if vara is equal to varb, print 'ok2' (use '==')
vara = 50
varb = 50.0


# if mya is greater than or equal to thisx, print 'ok3' (use '>=')
mya = 5
thisx = 4.9


# if var_x is the same string value as var_y, print 'ok4' (use '==')
var_x = 'hello'
var_y = 'hello'


# if the value of variable 'this' is NOT equal to variable 'that', print 'ok5'
# do this two ways, without using 'else' (use '!=' and '==' with not')
this = 5.0
that = 5.01


# Expected Output:

# ok
# ok2
# ok3
# ok4
# ok5
# ok5

