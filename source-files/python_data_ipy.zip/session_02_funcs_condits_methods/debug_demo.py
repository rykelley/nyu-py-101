
a = 5.05
b = 'hello'

ui = input('please enter a value: ')

iui = int(ui)

print(f'the value doubled is {iui * 2}')

