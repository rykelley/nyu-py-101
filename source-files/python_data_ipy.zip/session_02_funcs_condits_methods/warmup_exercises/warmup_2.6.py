# 2.6:  Use the string count() method to count the number of
# times 'or' appears in the below text.

msg = 'I am happy or sad or angry or mad or generous or stingy.'

# Sample program run:

# 5

