# 2.2:  Write a program that takes user input and compares it
# to the word 'quit'.  If input is equal to 'quit', the
# program prints quitting..., otherwise it prints not
# quitting....



# Sample program runs:

# please enter some text ('quit' to quit):  hello
# not quitting...

# please enter some text ('quit' to quit):  quit
# quitting...

