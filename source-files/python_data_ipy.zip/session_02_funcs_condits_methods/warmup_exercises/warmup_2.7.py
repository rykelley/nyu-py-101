# 2.7:  Modifying the previous program, take user input of a
# string to count, and then report the number of occurrences
# in the sentence.

msg = 'I am happy or sad or angry or mad or generous or stingy.'

# Sample program runs:

# please enter a string to search:  or
# 
# 5

# please enter a string to search:  m
# 
# 2

# please enter a string to search:  x
# 
# 0

