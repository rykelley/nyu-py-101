# 2.11:  Similar to the previous program, use a while loop and
# a counter to print "Happy birthday to you!" 10 times (do not
# print the integer count in this version).



# Sample program run:

# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!

