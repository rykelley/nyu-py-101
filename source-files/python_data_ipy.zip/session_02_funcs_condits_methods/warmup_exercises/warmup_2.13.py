# 2.13:  Modify the previous program to test the user input to
# make sure it is a usable integer.  (Hint:  as we did
# earlier, use str isdigit()).   If the input is not all
# digits, you can use exit('error message') to exit the
# program.



# Sample program runs:

# how many times should I greet you?  three
# error:  please enter an integer     # i.e., exit('error: please...')

# how many times should I greet you?  3
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!

# how many times should I greet you?  2
# Happy birthday to you!
# Happy birthday to you!

