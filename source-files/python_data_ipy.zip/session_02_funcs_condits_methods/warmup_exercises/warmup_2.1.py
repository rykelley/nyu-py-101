# 2.1:  Write a program that takes user input and prints
# whatever the user typed.



# Sample Output:

# please enter some text:  hey what up
# you just wrote:  "hey what up"

