# 2.3:  Extending the previous program, put the input() call
# inside a while True: loop.  If the user asks to quit, break
# out of the loop.  If not, allow the loop to return to the
# top (remember that all while loops automatically reset
# execution to the top of the loop when they reach the end;
# while True loops only stop looping when they hit break).



# Sample program run:

# please enter some text ('quit' to quit):  hello
# not quitting...
# please enter some text ('quit' to quit):  hello
# not quitting...
# please enter some text ('quit' to quit):  quit
# quitting...

