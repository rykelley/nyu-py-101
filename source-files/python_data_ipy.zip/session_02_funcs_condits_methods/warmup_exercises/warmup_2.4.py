# 2.4:  Write a program that asks user to enter a number and
# sees if it is greater than 0, less than 0 or equal to 0.
# (Remember that if can be used with else to have Python do
# one thing or another depending on the result of the test.)



# Sample program runs:

# please enter a number:  0
# your value is equal to 0.

# please enter a number:  -2
# your value is less than 0.

# please enter a number:  5
# your value is greater than 0.

