# 2.5:  Use input() to request the user to enter a number, and
# then test to see whether it is all digits (hint:  use the
# str .isdigit() method in an if test).  Simply print a
# success message if all digits, a failure message if no.



# Sample program runs:

# please enter an integer:  hello
# that was NOT an integer!

# please enter an integer:  55.5
# that was NOT an integer!

# please enter an integer:  "55"
# that was NOT an integer!

# please enter an integer:  55
# THANKS FOR THE INTEGER!

