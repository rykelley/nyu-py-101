# 2.12:  Modify the previous program to take user input with
# input() and print the message that many times.  (Hint:
# since we know that input() returns a string, the value will
# have to be converted to an int before it can be used in the
# while test with the loop count value.)



# Sample program run:

# how many times should I greet you?  3
# Happy birthday to you!
# Happy birthday to you!
# Happy birthday to you!

