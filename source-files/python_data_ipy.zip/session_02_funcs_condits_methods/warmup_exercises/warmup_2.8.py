# 2.8:  Taking a user input "substring", replace the substring
# in the string with 'x's.

msg = 'I am happy or sad or angry or mad or generous or stingy.'

# Sample program runs:

# I am happy or sad or angry or mad or generous or stingy.
# please enter a character to replace:  a
# I xm hxppy or sxd or xngry or mxd or generous or stingy.

# I am happy or sad or angry or mad or generous or stingy.
# please enter a character to replace:  or
# I am happy x sad x angry x mad x generous x stingy.

