# 2.10:  Use a while loop to count from 1 to 10.  Before the
# loop begins, initialize an integer counter (count) to 1.
# The while test should test to see if the counter is less
# than or equal to 10.  Inside the loop, "increment" count
# with count = count + 1 (i.e., it will be incremented upon
# each iteration of the loop).  Print each new value of the
# integer.  (Note that the slides contain this solution, so
# your job is to be able to code a program like this from
# scratch.  Repeat it until it is second nature if you can!)



# Expected Output:

# 1
# 2
# 3
# 4
# 5
# 6
# 7
# 8
# 9
# 10

