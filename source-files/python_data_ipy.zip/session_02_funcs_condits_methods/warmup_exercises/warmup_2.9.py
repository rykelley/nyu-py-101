# 2.9:  Based on the earlier exercise in which we said THANKS
# FOR THE INTEGER!, place your whole program inside a while
# True: block.  If the input is all digits (i.e., an integer),
# include the print statement indicating success, and follow
# it with a break statement to leave the loop.  As you know,
# if you do not break, at the end of the block while's
# "automatic return" will return to the top of the block
# automatically and your block will take input() again.



# Sample program run:

# please enter an integer:  hello
# that was NOT an integer!
# please enter an integer:  one?
# that was NOT an integer!
# please enter an integer:  5
# THANKS FOR THE INTEGER!

