# 4.12:  Show the 3rd highest value in this list.

import runreport

x = [8, 1, 0, 2, 23, 4, 5, 11]



# Expected Output:

# 8

