# 4.37:  Without looping, print a slice of the 5th through
# 10th words of pyku.txt.

import runreport



# Expected Output:

# ['This', 'parrot', 'has', 'ceased', 'to', 'be.']

