# 4.13:  Show the average of the top 50% of values in this
# list.

import runreport

x = [8, 1, 0, 2, 23, 4, 5, 11]



# Expected Output:

# 11.75

