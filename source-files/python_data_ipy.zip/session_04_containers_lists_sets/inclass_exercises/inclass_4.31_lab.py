# 4.31:  Collect a list of float values from revenue.csv from
# only those rows where the state can be found in the set of
# wanted states.

import runreport

wanted = {'NY', 'PA'}


# Expected Output:

# [239.5, 53.9, 211.5, 23.95]

