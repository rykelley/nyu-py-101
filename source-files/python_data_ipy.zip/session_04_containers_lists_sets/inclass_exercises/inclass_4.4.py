# 4.4:  Use range() to count.

# Without using a counter, create a for loop to iterate over
# each integer between 0 and 5.



# Expected Output:

# 0
# 1
# 2
# 3
# 4
# 5

