# 4.16:  Review:  loop through a list.

x = [3.3, 1.1, 4.4, 2.2]

# loop through the list and print each item individually (use 'for')



# Expected Output:

# 3.3
# 1.1
# 4.4
# 2.2

