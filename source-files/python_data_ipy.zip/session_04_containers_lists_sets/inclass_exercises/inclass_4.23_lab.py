# 4.23:  Show the average of the top 25% of values in
# dated_file.csv.

import runreport



# Expected Output:

# 26.075000000000003

