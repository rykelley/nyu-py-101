# 4.2:  List operations.

# Initialize a list of 5 strings.  Then perform the below
# operations.

# initialize your list of 5 strings
mylist = ['hello', 'there', 'fine', 'Python', 'friends']



# access and print the 2nd item (use list subscript)



# access and print the last item (use negative subscript)



# slice and print the first 3 items from the list (use list slice)



# slice and print the last 3 items from the list (leave off the 'upper bound')




# Expected Output:

# there
# friends
# ['hello', 'there', 'fine']
# ['Python', 'friends']
# 5
# ['Python', 'fine', 'friends', 'hello', 'there']

