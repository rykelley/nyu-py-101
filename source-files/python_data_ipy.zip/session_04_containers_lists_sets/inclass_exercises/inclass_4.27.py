# 4.27:  Check for item membership in a set.

# Check to see if the user's input value is in the set.  If it
# is print 'found it', otherwise print 'not found'.

# set of 4 items
x = {'a', 'b', 'c', 'd'}


item = input('check for an item:  ')

# your code here

