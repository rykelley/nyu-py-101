# 4.14:  Initialize an empty list.

# After initializing, check its length.




# Expected Output:

# 0

