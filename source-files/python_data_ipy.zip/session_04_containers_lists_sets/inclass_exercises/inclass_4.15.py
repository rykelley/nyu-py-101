# 4.15:  Add to a list using .append().

# In two statements, append two items 5.5 and 5.6 to your
# list, then print the entire list to show that the two items
# have been added.

x = [3.3, 1.1, 4.4, 2.2]



# Expected Output:

# [3.3, 1.1, 4.4, 2.2, 5.5, 6.6]

