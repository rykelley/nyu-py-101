# 4.26:  Initialize a set.

# Initialize a new set of 7-10 string and number values (make
# sure to include both).  Use .add() to add one new, and one
# repeat value to the set.  Print the set to see its contents.



# After executing, execute several more times, making note if
# the output changes.
# 
# PLEASE NOTE that the order of the printed set is expected to
# change but that this apparently does not happen in Jupyter.
# Run this code in PyCharm or other IDE to see the effect -
# the set's order changes every time you run the program.

