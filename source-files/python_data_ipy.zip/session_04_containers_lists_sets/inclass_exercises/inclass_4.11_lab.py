# 4.11:  Show the bottom 3 values in this list, sorted low-to-
# high.

import runreport

x = [8, 1, 0, 2, 23, 4, 5, 11]



# Expected Output:

# [0, 1, 2]

