# 4.22:  Show the top 3 values from the last column in
# dated_file.csv.

import runreport



# Expected Output:

# [28.3, 23.85, 19.09]

