# 4.8:  Show the average of the values in this list.

import runreport

x = [8, 1, 0, 2, 23, 4, 5, 11]



# Expected Output:

# 6.75

