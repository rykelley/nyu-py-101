# 4.21:  Calculate on average of values from a file.

# Show the average value from a list of the float values in
# file revenue.csv.

import runreport



# Expected Output:

# 94.57285714285716

