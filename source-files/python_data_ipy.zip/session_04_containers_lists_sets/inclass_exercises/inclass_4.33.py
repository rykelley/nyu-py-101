# 4.33:  Split a file as a list of words.

# Read 'pyku.txt' as a single string; use .split() to split
# into words.  Print the words.

filename = '../pyku.txt'

fh = open(filename)


# Expected Output:

# ["We're", 'out', 'of', 'gouda.', 'This', 'parrot', 'has',
#  'ceased', 'to', 'be.', 'Spam,', 'spam,', 'spam,', 'spam,',
#  'spam.']

