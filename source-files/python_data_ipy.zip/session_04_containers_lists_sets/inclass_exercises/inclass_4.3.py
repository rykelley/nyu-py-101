# 4.3:  List with summary functions.

x = [3.3, 1.1, 4.4, 2.2]


# in one statement, show count of items in a list (use len())



# sum up values in the list without looping (use sum())



# show maximum value in the list (use max())



# show minimum value in the list (use min())



# show list items sorted lowest to highest (use sorted())



# show list items sorted highest to lowest (add reverse=True)



# Expected Output:

# 4
# 11.0
# 4.4
# 1.1
# [1.1, 2.2, 3.3, 4.4]
# [4.4, 3.3, 2.2, 1.1]

