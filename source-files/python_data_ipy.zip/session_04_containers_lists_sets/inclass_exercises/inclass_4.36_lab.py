# 4.36:  Without looping, print the first word and also the
# last word of pyku.txt.

import runreport



# Expected Output:

# We're
# spam.

