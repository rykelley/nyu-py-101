# 4.9:  Find highest and lowest values in a list.

# In two simple statements (not using subscripting or
# sorted()), find the highest value and lowest value in this
# list.  Print each value.

import runreport

x = [8, 1, 0, 2, 23, 4, 5, 11]



# Expected Output:

# 23
# 0

