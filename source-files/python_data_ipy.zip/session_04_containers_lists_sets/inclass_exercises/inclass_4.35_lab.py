# 4.35:  Without looping, print the first and also the last
# line of pyku.txt.

import runreport



# Expected Output:

# We're out of gouda.
# 
# Spam, spam, spam, spam, spam.

