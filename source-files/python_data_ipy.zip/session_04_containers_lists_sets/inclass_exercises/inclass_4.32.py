# 4.32:  Split a string into lines with .splitlines().

# Perform the operations below.
# 

# split the below multi-line string into a list of string
# lines (use .splitlines()), and print the lines

text = """this is a line
this is another line
this is another line"""




print()

# read file 'pyku.txt' as a single string using .read()
# split the string into a list of strings lines as in previous
filename = '../pyku.txt'

fh = open(filename)



# Expected Output:

# ['this is a line', 'this is another line',
#  'this is another line']
# 
# ["We're out of gouda.", 'This parrot has ceased to be.',
#  'Spam, spam, spam, spam, spam.']

