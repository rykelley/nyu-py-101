# 4.39:  Without looping, show how many characters are in the
# first line of pyku.txt.

import runreport



# Expected Output:

# 20

