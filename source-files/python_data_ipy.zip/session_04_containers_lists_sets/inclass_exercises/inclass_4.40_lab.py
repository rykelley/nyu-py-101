# 4.40:  Without looping, show how many lines are in pyku.txt.

import runreport



# Expected Output:

# 3

