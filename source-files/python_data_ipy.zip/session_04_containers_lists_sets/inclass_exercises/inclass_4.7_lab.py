# 4.7:  Show the last 3 values in this list.

import runreport

x = [8, 1, 0, 2, 23, 4, 5, 11]



# Expected Output:

# [4, 5, 11]

