# 4.30:  Print only those lines of revenue.csv where the state
# can be found in the set of wanted states.

import runreport

wanted = {'NJ', 'PA'}


# Expected Output:

# Haddad's,PA,239.50
# Westfield,NJ,53.90
# The Store,NJ,211.50
# Awful's,PA,23.95

