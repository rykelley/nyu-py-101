# 9.2:  Create a module file named yourname.py where yourname
# is your first name.

# Create a def hello: function (that prints hello, world!)
# inside the yourname.py module.
# 
# Now in the same directory where you saved the module, create
# a python script.  In the script have an import greet
# statement, and then call the function through the module:
# greet.hello()
# 
# Save the file and then run it.

import yourname

yourname.hello()           # hello, world!

