# 9.14:  Multi-target assignment.

# In one statement, assign the variables a, b and c to x, y
# and z respectively.

import runreport

a = 5
b = 10
c = 15

# your code here


print(x)            # 5
print(y)            # 10
print(z)            # 15

# Expected Output:

# 5
# 10
# 15

