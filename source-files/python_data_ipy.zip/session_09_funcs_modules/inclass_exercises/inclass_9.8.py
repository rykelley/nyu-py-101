# 9.8:  Explore multi-target assignment errors.

# Try removing a variable from either the left or right side
# of the =.  What happens?

a = 5
b = 10
c = 15

x, y, z = a, b, c

