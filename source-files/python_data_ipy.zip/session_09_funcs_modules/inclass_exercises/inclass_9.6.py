# 9.6:  Write a function that returns None (without explicitly
# returning it).

# Write function greet(), which simply prints 'Hello, world!'.
# Printing x should show None.

# make sure your function does not attempt to return anything



x = greet()
print(x)         # None

