# 9.4:  Write a function that takes one argument and returns
# two values.

# Function mul_and_div takes an int argument and returns the
# value doubled and the value halved (/2)

# your def here
# you must not print inside the function
# you must not take input() inside the function
# you must not use 'a' inside the function



a = 5

d, h = mul_and_div(a)

print(d)       # 10
print(h)       # 2.5

