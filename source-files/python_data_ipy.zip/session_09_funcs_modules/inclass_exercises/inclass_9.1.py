# 9.1:  Write a function that takes an argument and returns a
# value.

# Function doubleit() takes one argument and returns its
# argument value doubled.

# your def here
# you must not print inside the function
# you must not take input() inside the function
# you must not use 'y' inside the function



y = 5

dy = doubleit(y)     # calling 'doubleit()', expecting one return value
print(dy)            # 10


