# 9.5:  Write a function that takes one positional (required)
# argument and one keyword (optional) argument.

# Define function mul, which should take a required integer
# argument and an optional integer argument.  If the optional
# arg is not passed, it should default to 1 (so that the
# argument value is multiplied by 1 and thus returned
# unchanged).

# your def here



a = 5

b = mul(5, multiplier=3)     # int, 15

c = mul(5)                   # int, 5

