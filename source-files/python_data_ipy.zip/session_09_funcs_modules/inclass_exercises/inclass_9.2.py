# 9.2:  Write another function that takes an argument and
# returns a value.

# Write a function get_greeting() that takes one string
# argument (a name) and returns "Hello, " followed by the name
# and an exclamation point.

# your def here
# you must not print inside the function
# you must not take input() inside the function
# you must not use 'x' or 'y' inside the function




x = 'World'
y = 'Guido'


# here, call get_greeting() with 'x' as argument
# make sure to expect a return value
# the return value should be 'Hello, World!'


# here, call get_greeting() with 'y' as argument
# make sure to expect a return value
# the return value should be 'Hello, Guido!'



