# 9.3:  Write a function that takes two arguments and returns
# one value.

# Define function multiplyem() that takes two numbers,
# multiplies them together, and returns the product.

# your def here
# you must not print inside the function
# you must not take input() inside the function
# you must not use 'a' or 'b' inside the function


a = 5
b = 10



# here, call multiplyem() with 'a' and 'b' as arguments
# make sure to expect a return value
# the return value should be 50


