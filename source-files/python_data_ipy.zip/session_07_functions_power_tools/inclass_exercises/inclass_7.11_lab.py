# 7.11:  Write a function with one argument and one return
# value.

# Define function get_first_item() that takes a string
# argument for a comma-separated CSV string line and returns
# just the first comma-separated item from the line.

import runreport

# your function def here


line = '2017-09-03,Alpha Corp.'

first = get_first_item(line)      # str, '2017-09-03'

print(first)                      # 2017-09-03

