# 7.23:  Modify each item in a list using a list
# comprehension.

# Write a list comprehension that uppercases each word in the
# list.  Print the list.

import runreport

x = ["It's", 'important', 'to', 'speak', 'moderately.']



# Expected Output:

# ["IT'S", 'IMPORTANT', 'TO', 'SPEAK', 'MODERATELY.']

