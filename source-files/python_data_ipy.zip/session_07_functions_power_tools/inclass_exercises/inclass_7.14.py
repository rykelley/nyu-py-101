# 7.14:  Show items in one set that are not in another set.
# Use set.difference().

xx = {'a', 'b', 'c', 'd'}
yy = {'b', 'd'}

# your code here


