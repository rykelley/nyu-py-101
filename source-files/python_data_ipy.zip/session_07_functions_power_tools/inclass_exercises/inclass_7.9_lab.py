# 7.9:  Write a function with one argument and one return
# value.

# Define function get_upper() that takes a string argument and
# returns the value uppercased.

import runreport

# your function def here



x = 'hello'
y = get_upper(x)         # str, 'HELLO'

print(y)                 # HELLO

