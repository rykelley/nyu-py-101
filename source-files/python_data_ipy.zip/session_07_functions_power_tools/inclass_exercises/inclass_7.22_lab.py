# 7.22:  Show all values in two sets.

# In a single statement, show a complete set of values
# contained in both sets.

import runreport

first_round = {'Miller, George', 'Adams, Abdul', 'Feiner, Billy', 'Pollinator, Jim'}

second_round = {'Adams, Abdul', 'Pollinator, Jim', 'Freeman, Kalley', 'Boom, Boom'}



# Expected Output:

# {'Miller, George', 'Adams, Abdul', 'Feiner, Billy', 'Pollinator, Jim',
#  'Freeman, Kalley', 'Boom, Boom'}

# (Note that set results may be in any order.)

