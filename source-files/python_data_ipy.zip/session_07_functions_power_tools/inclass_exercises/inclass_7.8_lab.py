# 7.8:  Write a function with two arguments and one return
# value.

# Define function get_prod() that takes two numeric arguments
# and returns their values multiplied together.

import runreport

# your function def here



aa = 5
bb = 9

c = get_prod(aa, bb)     # int, 45
print(c)                 # 45

