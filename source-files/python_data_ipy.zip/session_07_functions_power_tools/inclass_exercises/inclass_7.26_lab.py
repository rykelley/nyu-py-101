# 7.26:  Modify each item in a list using a list
# comprehension.

# Write a list comprehension that returns a list of strings
# that show each number as a currency value with comma
# separators (use the f'${num:,} format string, where num is
# the variable holding the number).  Also round each item to 2
# decimal places.

import runreport

aa = [35392.7381, 100353.949, 98.2203, 1035392.9942]



# Expected Output:

# ['$35,392.74', '$100,353.95', '$98.22', '$1,035,392.99']

