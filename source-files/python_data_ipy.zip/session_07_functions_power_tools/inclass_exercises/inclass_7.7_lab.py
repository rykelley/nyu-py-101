# 7.7:  Write a function with two arguments and one return
# value.

# Define function get_sum() that takes two numeric arguments
# and returns the values summed.  Note:  you must not use 'x'
# or 'y' inside the function, and you must not print inside
# the function - value must be returned.

import runreport

# your function def here

x = 50
y = 25

z = get_sum(x, y)
print(z)           # 75

