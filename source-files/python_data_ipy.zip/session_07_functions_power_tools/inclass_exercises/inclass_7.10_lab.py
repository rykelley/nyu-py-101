# 7.10:  Write a function with one argument and one return
# value.

# Define function get_split() that takes a string argument for
# a comma-separated CSV string line and returns a list of
# values from the split.

import runreport

# your function def here



line = 'this,that,other'

items = get_split(line)        # list, ['this', 'that', 'other']

print(items)                   # ['this', 'that', 'other']

