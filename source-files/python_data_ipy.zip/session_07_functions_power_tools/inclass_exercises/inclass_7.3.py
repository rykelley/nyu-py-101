# 7.3:  Write a function with two arguments and two return
# values.

# Define function 'doubletwo' that takes two numeric
# arguments, doubles each of them, and returns the two doubled
# values.  Note:  you must not use 'a' or 'b' inside the
# function, and you must not print inside the function -
# values must be returned.

# your function def here

a = 50
b = 10

c, d = doubletwo(a, b)

print(c)                # 100
print(d)                # 20

