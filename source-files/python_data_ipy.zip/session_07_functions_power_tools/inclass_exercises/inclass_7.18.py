# 7.18:  Use a list comprehension to filter items from a list.
# The new list should have only those values that are greater
# than 100.

temps = [86, 89, 93, 101, 92, 107, 90, 110]




# Expected Output:

# [101, 107, 110]

