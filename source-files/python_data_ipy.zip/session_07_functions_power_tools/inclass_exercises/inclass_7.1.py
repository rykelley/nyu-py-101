# 7.1:  Write a function that returns a value.

# Define a demonstration function return_ten() that returns
# the value 10.

def return_ten():

    # your function code here


val = return_ten()

print(val)          # 10

