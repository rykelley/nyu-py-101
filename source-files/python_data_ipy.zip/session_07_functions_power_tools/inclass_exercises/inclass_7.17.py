# 7.17:  Use a list comprehension to modify each item from a
# list.

# The new list should have each value from the old list
# doubled.

x = [1, 2, 3, 4]




# Expected Output:

# [2, 4, 6, 8]

