# 7.27:  Use a list comprehension to strip each line of a
# file.  Reading 'pyku.txt', use a list comprehension to
# generate a list of lines, each one stripped of the newline.
# Print the list as a whole - do not loop through it.

fh = open('../pyku.txt')

# your code here - resulting list of strings should
# be each line in 'pyku.txt' without newlines


