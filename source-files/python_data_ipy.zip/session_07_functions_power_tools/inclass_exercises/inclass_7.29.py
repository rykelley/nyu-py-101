# 7.29:  Use a list comprehension to extract a field from each
# row in a CSV file.  Reading 'revenue.csv', use a list
# comprehension to generate a list of company names.  Print
# the list as a whole.

fh = open('../revenue.csv')

# your code here


# The resulting list of strings should be each company listed
# in 'revenue.csv'

