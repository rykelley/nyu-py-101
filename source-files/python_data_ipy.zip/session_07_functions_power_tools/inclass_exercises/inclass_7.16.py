# 7.16:  Show all items that are in either of two sets.  Use
# set.union().

xx = {'a', 'b', 'c', 'd'}
yy = {'c', 'd', 'e', 'f'}

# your code here


