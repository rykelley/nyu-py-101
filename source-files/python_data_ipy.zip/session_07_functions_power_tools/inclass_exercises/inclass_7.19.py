# 7.19:  Use a list comprehension to both modify and filter
# items from a list.  The new list should have each value
# above 0 doubled.

aa = [-5, -3, 2, 0, 15, 73, -100]




# Expected Output:

# [4, 30, 146]

