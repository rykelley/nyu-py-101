# 7.6:  Write a function that returns a value.

# Define function 'get_rand()' that uses the following code to
# generate a random number between 1 and 10, then returns that
# number.  Note:  you must not print inside the function --
# value must be returned.

import runreport

# code to place inside your function:
# randval = random.randint(1, 10)


import random

# your function code here



num = get_rand()

print(num)

# If you see None printed, then you did not return anything
# from the function, but are printing the value returned from
# the function.  Make sure not to print inside the function.

