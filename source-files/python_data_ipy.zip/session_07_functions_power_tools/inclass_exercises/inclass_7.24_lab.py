# 7.24:  Modify each item in a list using a list
# comprehension.

# Write a list comprehension that returns the list of numbers
# showing their percentage value as a whole number (i.e.,
# multiplied by 100).

import runreport

pcts = [.353, .4911, .0309, .9998]



# Expected Output:

# [35.3, 49.11, 3.09, 99.98]

