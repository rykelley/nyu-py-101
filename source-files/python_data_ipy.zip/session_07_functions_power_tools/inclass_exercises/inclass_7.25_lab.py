# 7.25:  Modify selected items in a list using a list
# comprehension.

# Write a list comprehension that returns the square root of
# each number greater than 0.  To calculate square root, you
# can raise to the power of 0.5, or num ** 0.5 (where num is
# the variable holding the number).

import runreport

x = [5, 3, -3, 9, -7, 0, 10]



# Expected Output:

# [2.23606797749979, 1.7320508075688772, 3.0, 3.1622776601683795]

# Note that there may be small fractional differences on your
# computer.

