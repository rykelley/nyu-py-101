# 7.28:  Use a list comprehension to derive information about
# each line of a file.  Looping through 'pyku.txt', generate a
# new list with integers - the string length of each line in
# the file.  Print the list.

fh = open('../pyku.txt')

# your code here


# The resulting list of ints should be [20, 30, 30], assuming
# the lines have not been stripped or divided with
# splitlines()

