# 7.2:  Write a function with one argument and one return
# value.

# Define function 'doubleme' that takes one argument, doubles
# the value, and returns the doubled value.  Note:  you must
# not use 'a' or 'b' inside the function, and you must not
# print inside the function -- value must be returned.

# your function code here

a = 5
x = doubleme(a)
print(x)           # 10

b = 100
y = doubleme(b)
print(y)           # 200

