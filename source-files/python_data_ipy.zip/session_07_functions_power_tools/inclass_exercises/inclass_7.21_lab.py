# 7.21:  Show difference between two sets.

# In a single statement, show what is in set first_round that
# is not in set second_round; then show the reverse.

import runreport

first_round = {'Miller, George', 'Adams, Abdul', 'Feiner, Billy', 'Pollinator, Jim'}

second_round = {'Adams, Abdul', 'Pollinator, Jim', 'Freeman, Kalley', 'Boom, Boom'}





# Expected Output:

# {'Miller, George', 'Feiner, Billy'}
# {'Freeman, Kalley', 'Boom, Boom'}

# (Note that set results may be in any order.)

