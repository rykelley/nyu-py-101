# 7.15:  Show items common between two sets.  Use
# set.intersection().

xx = {'a', 'b', 'c', 'd'}
yy = {'c', 'd', 'e', 'f'}

# your code here


