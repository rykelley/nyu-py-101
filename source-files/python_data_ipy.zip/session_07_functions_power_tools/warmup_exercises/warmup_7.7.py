# 7.7:  Use the set .intersection() method to show which of
# the submitted addresses is on the blacklist.

blacklist = ['dark@lord.au', 'skeevy@guy.ny', 'bad@news.eu']
submitted = ['joe@me.com', 'dark@lord.au', 'marie@there.com']

