# 7.10:  Modify the list comprehension to double each value in
# the source list.

x = [1, 2, 3, 4]

y = [ item for item in x ]

