# 7.16:  Write a list comprehension that iterates over each
# line in the FF_tiny.txt file and slices out the year from
# each line.

fh = open('../FF_tiny.txt')


fh.close()

