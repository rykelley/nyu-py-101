# 7.13:  Write a list comprehension that builds a list of only
# positive values (greater than 0).

x = [7, -2, 9, -1, 0, 1, -3, 9, 3]



