# 7.20:  Build on the previous exercise - modify the list
# comprehension so that the returned words are uppercased.



# Expected Output:

# ['HELLO', 'DEAR', 'HEART', 'CHILD.']

