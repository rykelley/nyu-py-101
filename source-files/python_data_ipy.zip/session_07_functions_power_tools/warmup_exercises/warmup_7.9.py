# 7.9:  Run the below code to see that the list comprehension
# returns a list of the items from the 'source list'.

x = [1, 2, 3, 4]

y = [ item for item in x ]

