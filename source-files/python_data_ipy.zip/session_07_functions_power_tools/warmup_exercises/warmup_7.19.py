# 7.19:  Given the code below, write a list comprehension that
# only returns words longer than 3 letters - print the
# resulting list.

words = [ 'Hello', 'my', 'dear', 'the', 'heart', 'is',
          'a', 'child.' ]

# Expected Output:

# ['Hello', 'dear', 'heart', 'child']

