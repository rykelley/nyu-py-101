# 7.18:  Continuing with the solution from previous exercise,
# subscript the split() so that only one item from each list
# is passed to the resulting list.



