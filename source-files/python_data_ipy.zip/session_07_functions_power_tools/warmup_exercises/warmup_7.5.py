# 7.5:  Write a function addme() that takes two arguments,
# adds them together and returns the two arguments added /
# concatenated.  Call it thusly:

# your code here

x = addme(4, 5)
print(x)

y = addme('hey', 'you')
print(y)

# Expected Output:

# 9
# heyyou

