# 7.12:  Write a list comprehension that uppercases each
# string in the source list.

x = ['hi', 'there', 'pythonistas']

