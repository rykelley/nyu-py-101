# 7.14:  Write a list comprehension that builds a list of only
# names starting with underscore ('_').

dirlist = [ '__str__', '__repr__', 'upper', 'lower' ]


