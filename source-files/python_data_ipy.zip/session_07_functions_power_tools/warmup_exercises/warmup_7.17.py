# 7.17:  Write a list comprehension that splits each line,
# producing a list for each line in the file.

fh = open('../FF_tiny.txt')


fh.close()

