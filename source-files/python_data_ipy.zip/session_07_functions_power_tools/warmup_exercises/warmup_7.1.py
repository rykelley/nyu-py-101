# 7.1:  What is the correct way to call this function?

def do(arg):
    darg = arg * 2
    return darg



