# 7.22:  Continuing the previous exercise, use the list
# comprehension to remove the newline from each line in the
# file.  Print the resulting list - you should see each line
# of the file as before, but without the newline.



# Expected Output:

# ['id:address:city:state:zip',
#  'jk43:23 Marfield Lane:Plainview:NY:10023',
#  'ZXE99:315 W. 115th Street, Apt. 11B:New York:NY:10027',
#  'jab44:23 Rivington Street, Apt. 3R:New York:NY:10002',
#  'ak9:234 Main Street:Philadelphia:PA:08990',
#  'ap172:19 Boxer Rd.:New York:NY:10005',
#  'JB23:115 Karas Dr.:Jersey City:NJ:07127',
#  'jb29:119 Xylon Dr.:Jersey City:NJ:07127']

