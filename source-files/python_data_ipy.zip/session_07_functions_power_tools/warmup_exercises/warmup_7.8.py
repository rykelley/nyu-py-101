# 7.8:  Use the set .union() method to show the complete set
# of clients between the NE_clients and NW_clients list.

NE_clients = {'Alpha Industries', 'Beta Engrams, Inc.',
              'Gamma Products, Ltd.'}

NW_clients = {'Alpha Industries',  'Gamma Products, Ltd.',
              'Epsilon Publications'}

