# 7.2:  What is the correct way to call this function?

import random

def do():
    num = random.randint(1, 10)
    return num



