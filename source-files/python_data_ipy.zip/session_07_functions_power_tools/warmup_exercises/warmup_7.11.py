# 7.11:  Write a list comprehension that halves each value in
# the source list.

x = [1, 2, 3, 4]


