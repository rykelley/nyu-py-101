# 7.4:  What is the correct way to call this function?

def do(arg, otherarg):
    darg = arg * 2
    dotherarg = otherarg * 2
    return darg, dotherarg



