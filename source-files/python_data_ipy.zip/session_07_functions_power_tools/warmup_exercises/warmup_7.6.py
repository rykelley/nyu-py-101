# 7.6:  Use the set .difference() method to show which of the
# submitted addresses is not on the whitelist.

whitelist = {'joe@me.com', 'marie@there.com'}
submitted = {'joe@me.com', 'dark@lord.au', 'marie@there.com'}

