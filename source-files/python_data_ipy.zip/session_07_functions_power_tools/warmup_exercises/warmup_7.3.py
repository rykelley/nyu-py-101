# 7.3:  What is the correct way to call this function?

def do(arg, otherarg):
    svals = arg + otherarg
    return svals



