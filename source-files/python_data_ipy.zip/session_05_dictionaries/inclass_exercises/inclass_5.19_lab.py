# 5.19:  Split a string's fields to separate variables.

# Taking the previous one step further, split the below string
# into 3 items and unpack them into three separate variables
# called company, business and state.  Print company (should
# be Acme) and state (should be California).

import runreport

line = 'Acme,Manufacturing,California'



# Expected Output:

# Acme
# California

