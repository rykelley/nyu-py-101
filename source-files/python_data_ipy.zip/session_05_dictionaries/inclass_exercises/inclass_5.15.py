# 5.15:  Assign a CSV line to separate variables.

# Split the below CSV line into items, then assign the items
# to variables fname, lname and job.
# 
# Print the variables fname and job.

line = 'Joe,Wilson,Mechanic'




# Expected Output:

# Joe
# Mechanic

