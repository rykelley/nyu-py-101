# 5.23:  Use .get() to get a value for a key.  Input a key
# that exists in the dict and use .get() with the key to get
# the value.  Then input a key that does not exist and note
# the return value.

thisd = {'a': 1, 'b': 2, 'c': 3}

ukey = input('please enter a key: ')

# your code here

