# 5.9:  Sort dict keys by value.

# Sort the keys in this dict by value, low to high, then loop
# through and print each key and associated value.
# 
# Next, sort the keys by value by adding additional arguments
# to sorted(), key=uscitypop.get and reverse=True to sort the
# keys by value, high to low.
# 
# Print the sorted keys and see that they are in the order
# ['New York', 'Los Angeles', 'Chicago', 'Houston'].  Loop
# through these sorted keys and print sorted keys and values.

uscitypop = {  'Houston': 2.3,
               'Los Angeles': 4.0,
               'Chicago': 2.7,
               'New York': 8.4  }


# sort dict keys by value; print the keys



# loop through the sorted keys



    # print each sorted key and the value for that key in the dict




# Expected Output:

# New York 8.4
# Los Angeles 4.0
# Chicago 2.7
# Houston 2.3

