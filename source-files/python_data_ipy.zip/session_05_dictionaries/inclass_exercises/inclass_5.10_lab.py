# 5.10:  Review:  add a key.

# Take two inputs from the user and add them as key/value pair
# to the below dict.  Print the dict to see that it has been
# added.

import runreport

cocap = {'Apple': 1.98, 'Microsoft': 1.55, 'Amazon': 1.57 }

company = input('please enter a company name: ')
cap =     input('please enter a market cap in Tn: ')




# Expected Output:

# please enter a company name: Boorish
# please enter a market cap in Tn: .000009
# {'Apple': 1.98, 'Microsoft': 1.55, 'Amazon': 1.57, 'Boorish': '.000009'}

