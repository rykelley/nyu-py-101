# 5.8:  Sort dict keys.

# Sort the keys in this dict.  Print the list of sorted keys.
# Then loop through the sorted list and print each key as well
# as the value associated with that key from the dict.

uscitypop = {  'Houston': 2.3,
               'Los Angeles': 4.0,
               'Chicago': 2.7,
               'New York': 8.4  }


# sort and print the dict keys



# loop through the sorted keys



    # print each sorted key and the value for that key in the dict




# Expected Output:

# Chicago 2.7
# Houston 2.3
# Los Angeles 4.0
# New York 8.4

