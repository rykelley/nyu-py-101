# 5.18:  Assign a list to separate variables.

# Use multi-target assignment to "unpack" the items in the
# list to three separate variables called company, business
# and state.  Print company (should be Acme) and state (should
# be California).

import runreport

items = ['Acme', 'Manufacturing', 'California']



# Expected Output:

# Acme
# California

