# 5.5:  Review:  access a value based on a key.

# Take input from the user for a chemical compound, and print
# the boiling point associated with that key in the dict.

import runreport

bps = { 'water':    212,
        'methanol': 148.5,
        'wax':      698    }

compound = input('please enter a compound: ')



# Sample program run:

# please enter a compound: water
# 212

