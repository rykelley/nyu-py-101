# 5.2:  Add key/value pairs, then query dict.

# Initialize an empty dictionary.  Then in 2 statements, add 2
# key/value pairs using the variables below.  Then use a
# subscript to print the value 2.

key1 = 'a'
val1 = 1

key2 = 'b'
val2 = 2




# Expected Output:

# 2

