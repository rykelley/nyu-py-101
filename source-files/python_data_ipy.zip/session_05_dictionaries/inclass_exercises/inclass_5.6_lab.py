# 5.6:  Test for presence of a key.

# Again take user input for a key.  If the key exists in the
# dict, print the value for that key, but if the key is not
# found in the dict, print "not found".

import runreport

deage = { 'Biden': 77,
          'Harris': 55,
          'Sanders': 79 }

can = input('please enter the name of a candidate: ')



# Sample program run:

# please enter the name of a candidate: Harris
# 55

