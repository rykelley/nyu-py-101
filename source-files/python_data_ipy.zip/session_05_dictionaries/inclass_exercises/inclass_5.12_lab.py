# 5.12:  Loop through and print keys and values of a dict.

# Loop through the below dict and print each key and
# associated value.  You can use the comma between values when
# printing, e.g. print(this, that).

import runreport

planet_colors = { 'Mercury': 'green',
                  'Venus': 'white',
                  'Earth': 'blue',
                  'Mars': 'red',
                  'Jupiter': 'orange' }



# Expected Output:

# Mercury green
# Venus white
# Earth blue
# Mars red
# Jupiter orange

