# 5.7:  Loop through and print each dict key, then modify the
# loop to print the key as well as the value.

pdist = { 'Earth': 149.6,
          'Mars': 227.9,
          'Venus': 108.2,
          'Mercury': 57.9 }

# loop through the dict keys

    # print each key and the value for that key

# Expected Output:

# Earth 149.6
# Mars 227.9
# Venus 108.2
# Mercury 57.9

