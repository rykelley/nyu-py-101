# 5.22:  Get the length of a dict.  Use len().  Print the
# result.

thisd = {'a': 1, 'b': 2, 'c': 3}

# your code here

# Expected Output:

# 3

