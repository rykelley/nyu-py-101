# 5.2:  Given the following list:

mylist = ['Hey', 'there', 'I', 'am', 'amazing!']

# Initialize an empty dictionary.  Looping through each
# element in mylist, add a key/value pair to the dict where
# the key is the word and the value is the len() of the word.
# Print the dict.

# Expected Output:

# {'I': 1, 'there': 5, 'am': 2, 'Hey': 3, 'amazing!': 8}

