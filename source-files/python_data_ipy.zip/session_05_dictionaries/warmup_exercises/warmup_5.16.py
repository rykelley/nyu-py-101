# 5.16:  Extending the summing dictionary (or the counting
# dictionary) taken from revenue.csv, once the loop is
# complete, sort the dictionary using a standard sort (which
# will sort the dict by state names).



# Expected Output:

# # (note that the states are sorted alphabetically):
# NJ => 265.4
# NY => 133.16
# PA => 263.45

