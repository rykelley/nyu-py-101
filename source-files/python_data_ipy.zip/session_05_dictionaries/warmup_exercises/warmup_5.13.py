# 5.13:  Modifying the previous solution, sort the dictionary
# by value.  This done using the key=mydict.get argument to
# sorted() (assuming the variable name of your dictionary is
# mydict).



# Expected Output:

# c => 0.3
# a => 5
# b => 7

