# 5.12:  Starting with the following dictionary:

mydict = {'c': 0.3, 'b': 7, 'a': 5}

# Sort this dictionary by letter.  Since the sorted() function
# will return a list of dictionary keys, you can then loop
# through those keys to print the sorted keys, and use each
# key with the dictionary to look up each value associated
# with it.  Loop through the sorted keys, look up each value,
# and output each pair on a line.

# Expected Output:

# a => 5
# b => 7
# c => 0.3

