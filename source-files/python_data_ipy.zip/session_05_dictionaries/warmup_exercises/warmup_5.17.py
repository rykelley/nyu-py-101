# 5.17:  Now sort the summing dictionary by value.



# Expected Output:

# NY => 133.16
# PA => 263.45
# NJ => 265.4

