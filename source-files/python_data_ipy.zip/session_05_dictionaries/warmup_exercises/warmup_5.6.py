# 5.6:  Start with an empty dict.  Opening and looping through
# the file revenue.csv, load the name of the store as the key
# and the decimal point value as the value in the dict.  Print
# the dict.



# Expected Output:

# {"Hipster's": '11.98\n', 'Dothraki Fashions': '5.98\n',
#  "Awful's": '23.95\n', "Haddad's": '239.50\n',
#  'The Clothiers': '115.20\n', 'The Store': '211.50\n',
#  'Westfield': '53.90\n'}

