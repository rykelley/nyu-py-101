# 5.3:  Modify the previous script:  at the end of the script,
# instead of printing the dict directly, loop through the dict
# and print each key and value pair with a descriptive message
# (hint: use an f'' string for easy embedding of values within
# a string).



# Expected Output:

# "I" is len 1.
# "there" is len 5.
# "am" is len 2.
# "Hey" is len 3.
# "amazing!" is len 8.

