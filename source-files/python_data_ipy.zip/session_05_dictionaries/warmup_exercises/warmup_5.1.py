# 5.1:  Given the following dict:

mydict = {'a': 1, 'b': 2, 'c': 3}

# In two statements, add two key/value pairs to mydict
# (continuing the series values indicated).  Print the dict.

# Expected Output:

# {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

