# 5.5:  Extend the previous script to allow for the
# possibility of a missing key.  If the user's input word does
# not exist in the dict, print a statement to that effect
# (hint:  use the in operator to test for the existence of a
# key).



# Sample program runs:

# please enter a word:  I
# the word "I" is len 1

# please enter a word:  Jamie
# the word "Jamie" does not exist in the dictionary

