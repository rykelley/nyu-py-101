# 5.11:  Now reading from revenue.csv, sum up the values
# associated with each state.  (Hint:  this will be very much
# like the counting dictionary, but we will be adding float
# values to a sum (that starts at 0.0 for new keys; see the
# above explanation for working with keys new to the
# dictionary vs. "old" keys).)



# Expected Output:

# {'NY': 133.16, 'NJ': 265.4, 'PA': 263.45}

