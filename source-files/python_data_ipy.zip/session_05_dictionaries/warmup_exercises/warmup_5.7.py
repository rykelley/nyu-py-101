# 5.7:  Fix the previous script by removing the newline from
# each value (hint:  remove it when it is still part of the
# line by calling rstrip() on the line, before splitting).



# Expected Output:

# {"Hipster's": '11.98', 'Dothraki Fashions': '5.98',
#  "Awful's": '23.95', "Haddad's": '239.50',
#  'The Clothiers': '115.20', 'The Store': '211.50',
#  'Westfield': '53.90'}

