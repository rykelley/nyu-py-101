# 5.14:  Modifying the previous solution, reverse the sort
# using the reverse=True argument to sorted().



# Expected Output:

# b => 7
# a => 5
# c => 0.3

