# 5.4:  Modify the previous script:  at the end of the script,
# instead of looping through the dict, use input() to ask for
# one of the words.  If the user inputs one of the words, the
# program prints the word and its length.



# Expected Output:

# please enter a word:  there
# the word "there" is len 5

