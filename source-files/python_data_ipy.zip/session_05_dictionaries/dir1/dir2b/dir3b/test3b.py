""" test3b.py:  open and read a file """

fh = open('')

print(fh.read())


