""" test3a.py:  open and read a file """

fh = open('')

print(fh.read())


