""" test2a.py:  open and read a file """

fh = open('')

print(fh.read())


