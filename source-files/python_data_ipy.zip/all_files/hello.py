import sys

print('hello, world!')

print(f'sys.argv is: {sys.argv}')

