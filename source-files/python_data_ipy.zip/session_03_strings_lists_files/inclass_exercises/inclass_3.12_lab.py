# 3.12:  Loop through file and print.

# Loop through the file pyku.txt and print each line as you
# go.  You should see a blank line between each printed line
# (this is the newline character).

import runreport

filename = '../pyku.txt'



# Expected Output:

# We're all out of gouda.
# 
# This parrot has ceased to be.
# 
# Spam, spam, spam, spam, spam.

