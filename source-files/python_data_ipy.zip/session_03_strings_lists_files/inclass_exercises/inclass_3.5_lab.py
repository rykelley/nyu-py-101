# 3.5:  Print a word from undelimited string.

# Print the word best from dickens.  Then print times with the
# trailing comma stripped.

import runreport

dickens = 'It was the best of times, it was the worst of times.'



# Expected Output:

# best
# times

