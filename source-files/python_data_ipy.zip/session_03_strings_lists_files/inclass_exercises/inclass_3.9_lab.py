# 3.9:  Slice part of a string.

# Print the numeric SKU value from serial.

import runreport

serial = '#SKU000095327 MRCOFFEE 8CUP CAPUC'



# Expected Output:

# 000095327

