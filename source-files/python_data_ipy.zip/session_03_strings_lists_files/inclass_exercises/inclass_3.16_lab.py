# 3.16:  Loop through file and print one slice.

# Print the month and day from each line in FF_tiny.txt

import runreport

filename = '../FF_tiny.txt'

fh = open(filename)

for line in fh:
    # your code here


# Expected Output:

# 0701
# 0702
# 0103
# 0104
# 0201
# 0202
# 0103
# 0104
# 0105

