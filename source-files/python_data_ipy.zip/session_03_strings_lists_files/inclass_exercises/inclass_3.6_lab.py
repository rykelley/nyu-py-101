# 3.6:  Determine number of words in a string.

# In just two additional statements (not including printing),
# show the number of words in the string.

import runreport

swanns_way = 'For a long time I used to go to bed early.'



# Expected Output:

# 11

