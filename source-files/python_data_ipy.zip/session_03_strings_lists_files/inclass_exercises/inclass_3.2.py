# 3.2:  List operations.

# Perform the noted operations on list 'x'

x = ['hello', 'there', 'Python', 'friends']


# print the type of the list (use type())



# show the length of the list (use len())



# access and print the first item of the list (use list subscript)



# access and print the last item of the list (use negative subscript)



# use a variable index to print the last item
last_idx = -1



# loop through and print each individual item in the list (use 'for')



print()

# Expected Output:

# <class 'list'>
# hello
# friends
# 4
# 
# hello
# there
# Python
# friends

