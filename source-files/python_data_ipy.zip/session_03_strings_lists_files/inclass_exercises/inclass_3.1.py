# 3.1:  String operations.

# Perform the noted operations on strings 'sentence' and
# 'csv_line':

sentence = 'Hello  there   treasured  Python friends.'
csv_line = 'California,31,39.51,3200\n'


# use len() to determine the length of 'sentence'


# strip csv-


# strip 'sentence' of the period, then split into a list of 5 words


# split 'csv_line' into a list of 4 fields


# strip 'csv_line' of a newline, then split into 4 fields


# use variables to slice the first 5 characters
start_index = 0
end_index = 5


# special demo:  loop through a string?!
s = 'Hi there.'



# Expected Output:

# 40
# ['Hello', 'there', 'treasured', 'Python', 'friends.']
# ['California', '31', '39.51', '3200\n']
# ['California', '31', '39.51', '3200']
# Calif
# Calif
# H
# i
# 
# t
# h
# e
# r
# e
# .

