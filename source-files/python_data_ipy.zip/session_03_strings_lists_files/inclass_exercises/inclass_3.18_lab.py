# 3.18:  Loop through file, isolate values and add together.

# Looping through datafile.csv, isolate the int value and
# float value (4th and 5th fields) and add them together,
# printing each summed value as you loop.
# 

import runreport

name = '../datafile.csv'

fh = open(name)

for line in fh:
    # your code here


# Expected Output:

# 6.3
# 2.1
# 2.2
# 4.8
# 3.6

