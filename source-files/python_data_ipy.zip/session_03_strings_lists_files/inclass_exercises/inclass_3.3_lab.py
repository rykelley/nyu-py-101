# 3.3:  Print item from a delimited string.

# Select and print the value 39.51.  Do not use a slice.

import runreport

delimited = 'New York,31,39.51,3200'


# Expected Output:

# 39.51

