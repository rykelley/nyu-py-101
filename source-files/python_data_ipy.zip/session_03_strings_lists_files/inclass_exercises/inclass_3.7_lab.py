# 3.7:  Show selected words from a string.

# Print the 1st word in the setence, the 5th word in the
# sentence, and the last word in the sentence.

import runreport

gatsby = "In my younger and more vulnerable years my father gave me some advice..."


# Expected Output:

# In
# more
# advice...

