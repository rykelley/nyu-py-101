# 3.8:  Loop through words from a string.

# Print each word from this string on a separate line.

import runreport

moby = 'Call me Ishmael.'


# Expected Output:

# Call
# me
# Ishmael.

