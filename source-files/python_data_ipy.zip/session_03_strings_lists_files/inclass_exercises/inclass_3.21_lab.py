# 3.21:  Loop through file and selectively print using a
# slice.

# Looping through FF_tiny.txt, print the last float value on
# each line for the year 1927.

import runreport

filename = '../FF_tiny.txt'

fh = open(filename)

for line in fh:
    # your code here



# Expected Output:

# 0.015
# 0.011
# 0.022
# 0.018

