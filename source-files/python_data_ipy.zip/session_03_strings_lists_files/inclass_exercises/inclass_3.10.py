# 3.10:  List iteration and summary.

# Use 'for' to loop through list 'xval' and count the number
# of iterations, then extend it to also sum up the values.
# Print the sum and the count.

xval = [3.9, 0.3, 2.1, 0.03]



# Expected Output:

# 4
# 6.33

