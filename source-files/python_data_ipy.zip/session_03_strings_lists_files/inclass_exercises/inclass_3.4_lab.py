# 3.4:  Select number from a delimited string, use as number.

# Select the value 31, then double it to 62

import runreport

delimited = 'New York,31,39.51,3200'


# Expected Output:

# 62

