# 3.17:  Loop through file, isolate and double numeric value.

# Looping through datafile.csv, isolate the int value (4th
# field) and double it, printing each doubled value as you
# loop.

import runreport

fname = '../datafile.csv'

fh = open(fname)

for line in fh:
    # your code here


# Expected Output:

# 3
# 1
# 0
# 4
# 2

