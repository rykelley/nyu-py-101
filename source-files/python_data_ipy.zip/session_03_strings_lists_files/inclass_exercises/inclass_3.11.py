# 3.11:  File operations.

# Perform the below operations:

filename = '../pyku.txt'



# open file 'pyku.txt' and assign to variable 'fh' (use open())



# print the type of variable 'fh'


print()

# iterate over the variable 'fh' with 'for' and print each line in the file



# Expected Output:

# <class '_io.TextIOWrapper'>
# 
# We're out of gouda.
# 
# This parrot has ceased to be.
# 
# Spam, spam, spam, spam, spam.

