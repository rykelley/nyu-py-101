# 3.14:  Loop through file and count.

# Loop through the file pyku.txt and keep a running count of
# each line.  Print the count at the end.

import runreport

filename = '../pyku.txt'

fh = open(filename)

for line in fh:
    # your code here


# Expected Output:

# 3

