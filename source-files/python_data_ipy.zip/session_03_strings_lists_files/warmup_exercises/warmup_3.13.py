# 3.13:  start a new program based on the logic of the
# previous one, to build a sum of values:  before the loop
# begins, initialize a "floatsum" variable to 0.  then looping
# through the data, if the year is 1928, select out the 2nd
# column (the 1st column of float values), convert it to a
# float, and add it to the floatsum variable.  report the sum
# at the end.



# Expected Output:

# 3.88

