# 3.4:  new program:  open the FF_abbreviated file, loop
# through it line-by-line and print just the year from each
# line, so you see just a 4-digit year from each line.  (hint:
# take a 4-digit slice of each line and instead of printing
# the line, print the slice)



# Expected Output:

# 1926
# 1926
# 1926
# 1926
# 1926
# 1926
# 1926
# 1926
# 1926
# 1927
# 1927
# 1927
# 1927
# 1927
# 1927
# 1927
# 1927
# 1928
# 1928
# 1928
# 1928
# 1928
# 1928
# 1928
# 1928
# 1928

