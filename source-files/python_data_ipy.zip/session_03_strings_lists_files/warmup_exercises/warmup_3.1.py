# 3.1:  open the FF_abbreviated.txt file, reading it line-by-
# line.  print each line



# Expected Output:

# 19260701    0.09    0.22    0.30   0.009
# 
# 19260702    0.44    0.35    0.08   0.009
# 
# 19260706    0.17    0.26    0.37   0.009
# 
# ...intermediate output omitted...
# 
# 19280301    0.23    0.04    0.12   0.011
# 
# 19280302    0.07    0.01    0.66   0.011
# 
# 19280303    0.49    0.01    0.64   0.011

