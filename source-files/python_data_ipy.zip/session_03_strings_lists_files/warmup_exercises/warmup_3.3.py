# 3.3:  building on the previous program, print the value of
# the counter in front of each line, so that each line is
# printed with its line number.  (To print the number
# alongside of the line, you can use a format string,
# concatenation with str(), or a comma, as in

# print(count, line)



# Expected Output:

# 1 19260701    0.09    0.22    0.30   0.009
# 
# 2 19260702    0.44    0.35    0.08   0.009
# 
# 3 19260706    0.17    0.26    0.37   0.009
# 
# ...intermediate output omitted...
# 
# 24 19280301    0.23    0.04    0.12   0.011
# 
# 25 19280302    0.07    0.01    0.66   0.011
# 
# 26 19280303    0.49    0.01    0.64   0.011
# 
# 26

