# 3.11:  building on the previous program, convert each of the
# Mkt-RF (2nd column) values to a float, and multiply that
# value * 2.  Print the column value and then the doubled
# value on the same line (using a comma between them in a
# print statement is probably the easiest way to print a
# number and string together).



# Expected Output:

# 0.43 0.86
# 0.14 0.28
# 0.71 1.42
# 0.25 0.5
# 0.44 0.88
# 1.12 2.24
# 0.23 0.46
# 0.07 0.14
# 0.49 0.98

