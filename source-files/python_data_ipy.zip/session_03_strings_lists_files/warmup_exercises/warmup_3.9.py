# 3.9:  adjusting the previous program, print the 2nd column
# from each line instead of the 1st column.  This should print
# the leftmost column of floats.



# Expected Output:

# 0.09
# 0.44
# 0.17
# 0.82
# 0.46
# 0.35
# 0.54
# 0.04
# 0.48
# 0.97
# 0.30
# 0.00
# 0.72
# 0.17
# 0.38
# 1.12
# 1.01
# 0.43
# 0.14
# 0.71
# 0.25
# 0.44
# 1.12
# 0.23
# 0.07
# 0.49

