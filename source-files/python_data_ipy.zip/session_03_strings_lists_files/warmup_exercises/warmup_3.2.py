# 3.2:  building on the previous program, set up a counter
# that is set to 0 before the loop begins, and counts 1 for
# each line in the file.  print each line in the file, and at
# the end report the count.



# Expected Output:

# 
# 19260701    0.09    0.22    0.30   0.009
# 
# 19260702    0.44    0.35    0.08   0.009
# 
# 19260706    0.17    0.26    0.37   0.009
# 
# ...intermediate output omitted...
# 
# 19280301    0.23    0.04    0.12   0.011
# 
# 19280302    0.07    0.01    0.66   0.011
# 
# 19280303    0.49    0.01    0.64   0.011
# 
# 26

