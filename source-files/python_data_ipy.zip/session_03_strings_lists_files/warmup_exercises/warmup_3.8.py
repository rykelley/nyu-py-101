# 3.8:  building on the previous program, instead of printing
# the entire list from each line, print just the 1st column
# (the year-month-day) of each line.  (Hint:  since the string
# split() method returns a list, you can easily print just one
# column from that list by using a subscript (i.e., index
# number inside square brackets after the list name).



# Expected Output:

# 19260701
# 19260702
# 19260706
# 19260802
# 19260803
# 19260804
# 19260901
# 19260902
# 19260903
# 19270103
# 19270104
# 19270201
# 19270202
# 19270203
# 19270301
# 19270302
# 19270303
# 19280103
# 19280104
# 19280105
# 19280201
# 19280202
# 19280203
# 19280301
# 19280302
# 19280303

