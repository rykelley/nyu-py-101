# 3.12:  building on the previous program, add in the counter,
# but increment the counter only if the year is 1928, so
# you're only counting the 1928 lines.  print each count
# number, the float value, and the doubled float value on the
# same line.



# Expected Output:

# 1 0.43 0.86
# 2 0.14 0.28
# 3 0.71 1.42
# 4 0.25 0.5
# 5 0.44 0.88
# 6 1.12 2.24
# 7 0.23 0.46
# 8 0.07 0.14
# 9 0.49 0.98

