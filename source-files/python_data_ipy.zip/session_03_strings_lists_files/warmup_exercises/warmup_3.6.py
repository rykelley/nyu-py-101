# 3.6:  building on the previous program, add the counter from
# one of the earlier programs and this time count just the
# lines that match the year '1928'.  print the total count at
# the end.  (Hint:  make sure that the counter is incremented
# inside the if block, i.e., only if the year matches.)



# Expected Output:

# 19280103    0.43    0.90    0.20   0.010
# 
# 19280104    0.14    0.47    0.01   0.010
# 
# 19280105    0.71    0.14    0.15   0.010
# 
# 19280201    0.25    0.56    0.71   0.014
# 
# 19280202    0.44    0.15    0.18   0.014
# 
# 19280203    1.12    0.48    0.42   0.014
# 
# 19280301    0.23    0.04    0.12   0.011
# 
# 19280302    0.07    0.01    0.66   0.011
# 
# 19280303    0.49    0.01    0.64   0.011
# 
# 9

